#include <iostream>
class IObject
{
private:
    /* data */
public:
    IObject();
    ~IObject();
    virtual std::string ToString();
};
