#ifndef TIME_H
#include "Time.h"
#include "Err.h"
Time::Time(int hours, int minutes, int seconds){
    this->hours = hours;
    this->minutes = minutes;
    this->seconds = seconds;
}

Time::~Time()
{
}

int Time::compareTo(IComparable *objComparedTo) const
{
    Time *time = dynamic_cast<Time *>(objComparedTo);
    if (time != nullptr && time->getHours() == hours && time->getMinutes() == minutes && time->getSeconds() == seconds )
    {
         return 0;
    } else if (time != nullptr && time->getHours() <= hours && time->getMinutes() <= minutes && time->getSeconds() <= seconds )
    {
         return -1;
    }else if (time != nullptr && time->getHours() >= hours && time->getMinutes() >= minutes && time->getSeconds() >= seconds )
    {
         return 1;
    }
    
    throw Err("an error has occured");
}

void Time::sortField(IComparable** array, int arraySize){
    int i, j;  
    for (i = 0; i < arraySize-1; i++)      
    // Last i elements are already in place  
    for (j = 0; j < arraySize-i-1; j++)  
        if (array[j] > array[j+1])  {
            auto switchedTime = array[i];
            array[i] = array[i+1];
            array[i+1] = switchedTime;
        }    
}

std::string Time::ToString()
{
	return  this->getHours() + "h " + this->getMinutes() + 'm ' + this->getSeconds() + 's ';
}

int Time::getSeconds() const
{
    return seconds;
}
int Time::getMinutes() const
{
    return minutes;
}
int Time::getHours() const
{
    return hours;
}

#endif TIME_H