class IComparable
{
private:
    /* data */
public:
    IComparable();
    ~IComparable();
    virtual int compareTo(IComparable* obj) const;
};

IComparable::IComparable()
{
}

IComparable::~IComparable()
{
}
