#include <democlass.h>

int main() {
	DemoClass dc{};
	dc.HelloWorld();

	return 0;
}