#include "democlass.h"
#include <iostream>

void DemoClass::HelloWorld()
{
	std::cout << "Hello World from DLL library" << std::endl;
}
