#ifndef __DEMOCLASS_H
#define __DEMOCLASS_H

#include "platform.h"

struct DLL_SPEC DemoClass {
public:

	void HelloWorld();

};

#endif